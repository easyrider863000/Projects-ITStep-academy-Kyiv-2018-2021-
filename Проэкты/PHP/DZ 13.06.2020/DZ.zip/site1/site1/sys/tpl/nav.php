<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php?id=main">Robotics</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php?id=main">Главная <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?id=news">Новости</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?id=about">Про сайт</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?id=contact">Контакты</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Галерея</a>
                    <div class="dropdown-menu" aria-labelledby="dropdown01">
                        <a class="dropdown-item" href="index.php?id=gallery1">Роботы-андроиды</a>
                        <a class="dropdown-item" href="index.php?id=gallery2">Боевые роботы</a>
                        <a class="dropdown-item" href="index.php?id=gallery3">Промышленные роботы</a>
                    </div>
                </li>
            </ul>
            <ul class="navbar-nav navbar-right">
                <li class="nav-item">
                    <a class="nav-link" href="" style="margin-right: 50px">
                        Привет, <?=$page_user?>!
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?id=entry">Вход</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php?id=reg">Регистрация</a>
                </li>
            </ul>
        </div>
  </div>
</nav>