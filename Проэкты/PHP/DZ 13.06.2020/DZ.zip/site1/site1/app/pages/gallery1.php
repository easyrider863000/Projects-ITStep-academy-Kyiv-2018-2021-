<?php 
    $title = 'Андроиды';
    function get_content() {
?>
        <div id="main_box" class="container">
            <h3>Андроиды</h3>
            <hr>
        </div>
<?php
    }
?>