<?php 
    $title = 'Регистрация';
    function get_content() {
        if (empty($_POST['submit'])) {
?>
            <div id="main_box" class="container">
                <h3>Регистрация</h3>
                <hr>
                <form id="form1" action="index.php?id=reg" method="post">
                    <div class="form-group">
                        <label for="login">Логин:</label><br>
                        <input type="text" id="login" name="login" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="pass1">Пароль:</label><br>
                        <input type="password" id="pass1" name="pass1" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="pass2">Повтор:</label><br>
                        <input type="password" id="pass2" name="pass2" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="email">E-Mail:</label><br>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <input type="submit" id="submit" name="submit" value="Отправить" class="btn btn-success">
                        <input type="reset" id="reset" name="reset" value="Очистить" class="btn btn-success">
                    </div>
                </form>
            </div>
<?php
        } else {
            date_default_timezone_set('Europe/Kiev');

            $login = trim(htmlspecialchars($_POST['login']));
            $pass1 = trim(htmlspecialchars($_POST['pass1']));
            $pass2 = trim(htmlspecialchars($_POST['pass2']));
            $email = trim(htmlspecialchars($_POST['email']));

            echo('<div id="report_box" class="container">');
            echo('<h2>Отчет о результатах регистрации</h2>');
            echo('<hr><h5>');

            $passw = md5($pass1);
            $regdate = date('Y-m-d H:i:s');
            $status = 'usual';

            /*
            echo("login: $login <br>");
            echo("pass1: $pass1 <br>");
            echo("pass2: $pass2 <br>");
            echo("passw: $passw <br>");
            echo("email: $email <br>");
            echo("regdate: $regdate <br>");
            */

            // 1. Проверка занятости логина ...
            // --------------------------------

            // ! Сохранение данных в БД: (2. - Перенос логики в отдельных класс модели)
            // ------------------------------------------------------------------------
            $mysqli = new mysqli('localhost', 'root', 'root', 'robotics');
            $query = "INSERT INTO users (login, passw, email, regdate, status) ";
            $query .= "VALUES ((?), (?), (?), (?), (?))";
            $stmt = $mysqli->prepare($query);

            echo('<span style="color: red">Отправка запроса</span><br>');
            
            $stmt->bind_param("sssss", $login, $passw, $email, $regdate, $status);
            $stmt->execute();
            $stmt->close();

            echo('<span style="color: green">Регистрация успешно завершена</span>');

            echo('</h5></div>');
        }   
    }
?>