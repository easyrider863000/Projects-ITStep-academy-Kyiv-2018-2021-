<?php 
    $title = 'Про сайт';
    function get_content() {
?>
        <div id="main_box" class="container">
            <h3>Про сайт</h3>
            <hr>
        </div>
<?php
    }
?>