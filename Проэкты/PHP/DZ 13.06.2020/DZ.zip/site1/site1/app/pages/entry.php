<?php
$title = 'Вход';
function get_content()
{
    if (empty($_POST['submit'])) {
?>
        <div id="main_box" class="container">
            <h3>Вход</h3>
            <hr>
            <form id="form1" action="index.php?id=entry" method="post">
                <div class="form-group">
                    <label for="login">Логин:</label><br>
                    <input type="text" id="login" name="login" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="pass1">Пароль:</label><br>
                    <input type="password" id="pass1" name="pass1" class="form-control" required>
                </div>
                <div class="form-group">
                    <input type="submit" id="submit" name="submit" value="Отправить" class="btn btn-success">
                    <input type="reset" id="reset" name="reset" value="Очистить" class="btn btn-success">
                </div>
            </form>
        </div>
<?php
    } else {
        
        $login = trim(htmlspecialchars($_POST['login']));
        $pass1 = trim(htmlspecialchars($_POST['pass1']));

        echo ('<div id="report_box" class="container">');
        echo ('<hr><h5>');
        $passw = md5($pass1);

        $mysqli = new mysqli('localhost', 'root', 'root', 'robotics');
        $query = "SELECT login, passw from users where passw='$passw'";
        $stmt = $mysqli->query($query);
        $obje = $stmt->fetch_assoc();
        if($login == $obje['login']){

            $_SESSION['user'] = $obje['login'];   
            echo ("<span style='color: red'>Добро пожаловать, $obje[login]</span><br>");
            echo ('</h5></div>');
        }
        else{
            
            echo ('<span style="color: green">Некорректные данные</span>');   
            echo ('</h5></div>');
        }
    }
}
?>