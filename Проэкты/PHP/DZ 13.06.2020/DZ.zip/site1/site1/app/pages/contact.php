<?php 
    $title = 'Контакты';
    function get_content() {
?>
        <div id="main_box" class="container">
            <h3>Контакты</h3>
            <hr>
        </div>
<?php
    }
?>