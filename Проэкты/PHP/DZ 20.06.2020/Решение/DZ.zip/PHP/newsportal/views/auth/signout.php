<?php
$title = 'Выход';
?>
<div id="main_box" class="container">
    <h3>Выход</h3>
    <hr>
    <form id="form1" action="logoutform" method="post">
        <div class="form-group">
            <input type="submit" id="submit" name="submit" value="Выйти" class="btn btn-success">
        </div>
    </form>
</div>