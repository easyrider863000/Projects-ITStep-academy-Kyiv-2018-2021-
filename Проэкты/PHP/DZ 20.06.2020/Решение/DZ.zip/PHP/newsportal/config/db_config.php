<?php

return [
    'type' => 'mysql',
    'host' => 'localhost',
    'dbname' => 'newsportal',
    'charset' => 'utf8',
    'user' => 'root',
    'pass' => 'root'
];
