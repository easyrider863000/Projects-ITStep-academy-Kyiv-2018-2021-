﻿using Exam.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Exam.ViewModels
{
    [Serializable]
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        BinaryFormatter bf = new BinaryFormatter();
        RelayCommand add;
        public ICommand AddCommand
        {
            get
            {
                if (add == null)
                    add = new RelayCommand(x =>
                    {
                        SelectedAuto = new Auto(
                            "?", "?", new AutoCountryManufacturer(0, "не выбрано"), new AutoBodyType(0, "не выбрано"), 0, 0, 0, 0, new List<AutoPhoto> { new AutoPhoto() { Id = 10, Path = "/Images/10.jpg" } });
                        Autos.Add(SelectedAuto);
                        // SelectedStudent = s;
                    }, null);
                return add;
            }
        }

        RelayCommand remove;
        public ICommand RemoveCommand
        {
            get
            {
                if (remove == null)
                {
                    remove = new RelayCommand(x =>
                    {
                        if (MessageBox.Show($"Are you delete {SelectedAuto.Name} {SelectedAuto.Model} ?", "Delete record", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
                        {
                            Autos.Remove(SelectedAuto);
                            SelectedAuto = Autos.LastOrDefault();
                        }
                    }, x => SelectedAuto != null);

                }
                return remove;
            }
        }


        RelayCommand save;
        public ICommand SaveCommand
        {
            get
            {
                if (save == null)
                {
                    save = new RelayCommand(x =>
                    {
                        using (FileStream sr = new FileStream("autos.bin",FileMode.OpenOrCreate))
                        {
                            bf.Serialize(sr, Autos);
                        }
                    }, null);

                }
                return save;
            }
        }



        void SelectMenuThemes(object o)
        {
            var menu = o as Control;
            string style = menu.Tag as string;

            var uri = new Uri("Themes/" + style + ".xaml", UriKind.Relative);
            ResourceDictionary resourceDict = Application.LoadComponent(uri) as ResourceDictionary;
            Application.Current.Resources.Clear();
            Application.Current.Resources.MergedDictionaries.Add(resourceDict);
        }
        void PrevNextSelected(object o)
        {
            if (o == null)
                return;
            var elem = o as Control;
            string tag = elem.Tag as string;
            if (tag == "prev")
            {
                if (SelectedAuto.CurrentPhoto == 0)
                {
                    SelectedAuto.CurrentPhoto = SelectedAuto.Photos.Count;
                }
                SelectedAuto.CurrentPhoto--;
                Notify("SelectedPhoto");
            }
            else if (tag == "next")
            {
                if (SelectedAuto.CurrentPhoto+1 == SelectedAuto.Photos.Count)
                {
                    SelectedAuto.CurrentPhoto = -1;
                }
                SelectedAuto.CurrentPhoto++;
                Notify("SelectedPhoto");
            }
        }

        RelayCommand menuThemes;
        public ICommand MenuThemes
        {
            get
            {
                if (menuThemes == null)
                {
                    menuThemes = new RelayCommand(SelectMenuThemes, null);
                }
                return menuThemes;
            }
        }

        RelayCommand prevNextCommand;
        public ICommand PrevNextCommand
        {
            get
            {
                if (prevNextCommand == null)
                {
                    prevNextCommand = new RelayCommand(PrevNextSelected, null);
                }
                return prevNextCommand;
            }
        }

        public ObservableCollection<Auto> Autos { get; set; }
        private Auto _SelectedAuto { get; set; }

        public Auto SelectedAuto
        {
            get { return _SelectedAuto; }
            set
            {
                _SelectedAuto = value;
                Notify("SelectedAuto");
                Notify("SelectedPhoto");
            }
        }

        public string SelectedPhoto {
            get
            {
                return SelectedAuto.Photos[SelectedAuto.CurrentPhoto].Path;
            }
            set { } }
        public ObservableCollection<AutoCountryManufacturer> Manufacturers { get; set; }
        public ObservableCollection<AutoBodyType> BodyTypes { get; set; }
        public MainWindowViewModel()
        {
            if (!File.Exists("autos.bin"))
            {
                Autos = new Cars();
                Manufacturers = new StorageCountryManufacturers();
                BodyTypes = new StorageBodyTypes();
                SelectedAuto = Autos.FirstOrDefault();
                SelectedPhoto = SelectedAuto.Photos[SelectedAuto.CurrentPhoto].Path;
            }
            else
            {
                using (FileStream w = new FileStream("autos.bin", FileMode.Open))
                {
                    Autos = (bf.Deserialize(w) as ObservableCollection<Auto>);
                    Manufacturers = new StorageCountryManufacturers();
                    BodyTypes = new StorageBodyTypes();
                    SelectedAuto = Autos.FirstOrDefault();
                    SelectedPhoto = SelectedAuto.Photos[SelectedAuto.CurrentPhoto].Path;
                }
            }
        }

        public void Notify([CallerMemberName]string s = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(s));
        }
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
