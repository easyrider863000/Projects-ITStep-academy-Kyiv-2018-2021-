﻿using System.Collections.ObjectModel;

namespace Exam.Models
{
    [System.Serializable]
    public class StorageCountryManufacturers:ObservableCollection<AutoCountryManufacturer>
    {
        public StorageCountryManufacturers()
        {
            Add(new AutoCountryManufacturer(0,"не выбрано"));
            Add(new AutoCountryManufacturer(1,"Germany"));
            Add(new AutoCountryManufacturer(2,"Italy"));
            Add(new AutoCountryManufacturer(3,"Spain"));
            Add(new AutoCountryManufacturer(4,"USA"));
            Add(new AutoCountryManufacturer(5,"Russia"));
            Add(new AutoCountryManufacturer(6,"Ukrane"));
            Add(new AutoCountryManufacturer(7,"India"));
            Add(new AutoCountryManufacturer(8,"Thailand"));
            Add(new AutoCountryManufacturer(9,"Africa"));
            Add(new AutoCountryManufacturer(10,"Dania"));
        }
    }
}
