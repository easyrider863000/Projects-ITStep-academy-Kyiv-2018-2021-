﻿using System.Collections.ObjectModel;

namespace Exam.Models
{
    [System.Serializable]
    public class StorageBodyTypes:ObservableCollection<AutoBodyType>
    {
        public StorageBodyTypes()
        {
            Add(new AutoBodyType(0, "не выбрано"));
            Add(new AutoBodyType(1, "Купе"));
            Add(new AutoBodyType(2, "Седан"));
            Add(new AutoBodyType(3, "Внедорожник"));
            Add(new AutoBodyType(4, "Кабриолет"));
            Add(new AutoBodyType(5, "Универсал"));
            Add(new AutoBodyType(6, "Хэтчбек"));
            Add(new AutoBodyType(7, "Лифтбек"));
            Add(new AutoBodyType(8, "Родстер"));
            Add(new AutoBodyType(9, "Тарга"));
            Add(new AutoBodyType(10, "Минивэн"));
        }
    }
}
