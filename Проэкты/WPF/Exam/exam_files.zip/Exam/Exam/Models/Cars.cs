﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Exam.Models
{
    [System.Serializable]
    public class Cars: ObservableCollection<Auto>
    {
        public Cars()
        {
            Add(new Auto(
                "BMW",
                "640d f05",
                new AutoCountryManufacturer(1, "Germany"),
                new AutoBodyType(1, "Купе"),
                2410,
                2993,
                313,
                2015,
                new List<AutoPhoto>()
                { new AutoPhoto() { Id = 1, Path = "/Images/1.jpg" }, new AutoPhoto() { Id = 2, Path = "/Images/2.jpg" }, new AutoPhoto() { Id = 3, Path = "/Images/3.jpg" } }
            ));
            Add(new Auto(
                "BMW",
                "M5 Competition f90",
                new AutoCountryManufacturer(1, "Germany"),
                new AutoBodyType(2, "Седан"),
                1930,
                4395,
                625,
                2018,
                new List<AutoPhoto>()
                { new AutoPhoto() { Id = 4, Path = "/Images/4.jpg" }, new AutoPhoto() { Id = 5, Path = "/Images/5.jpg" }, new AutoPhoto() { Id = 6, Path = "/Images/6.jpg" } }
            ));
            Add(new Auto(
                "BMW",
                "X5 M",
                new AutoCountryManufacturer(1, "Germany"),
                new AutoBodyType(3, "Внедорожник"),
                2970,
                4395,
                575,
                2014,
                new List<AutoPhoto>()
                { new AutoPhoto() { Id = 7, Path = "/Images/7.jpg" }, new AutoPhoto() { Id = 8, Path = "/Images/8.jpg" }, new AutoPhoto() { Id = 9, Path = "/Images/9.jpg" } }
            ));
        }
    }
}
