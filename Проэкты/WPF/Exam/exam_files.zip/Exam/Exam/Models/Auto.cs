﻿using System;
using System.Collections.Generic;

namespace Exam.Models
{
    [Serializable]
    public class Auto
    {
        public Auto() { }
        public Auto(string name, string model, AutoCountryManufacturer countryManufacturer, AutoBodyType bodyType, int mass, double engineCapacity, int power, int yearOfIssue, List<AutoPhoto> autophotos)
        {
            Name = name;
            Model = model;
            CountryManufacturer = countryManufacturer;
            BodyType = bodyType;
            Mass = mass;
            EngineCapacity = engineCapacity;
            Power = power;
            YearOfIssue = yearOfIssue;
            Photos = autophotos;
            CurrentPhoto = 0;
        }
        public List<AutoPhoto> Photos { get; set; }
        public int CurrentPhoto { get; set; }
        public string Name { get; set; }
        public string Model { get; set; }
        public AutoCountryManufacturer CountryManufacturer { get; set; }
        public AutoBodyType BodyType { get; set; }
        public int Mass { get; set; }
        public double EngineCapacity { get; set; }
        public int Power { get; set; }
        public int YearOfIssue { get; set; }
    }
}
