﻿using System;

namespace Exam.Models
{
    [Serializable]
    public class AutoBodyType:System.IEquatable<AutoBodyType>
    {
        public AutoBodyType() { }
        public AutoBodyType(int id, string bodyName) { Id = id; BodyName = bodyName; }
        public int Id { get; set; }
        public string BodyName { get; set; }

        public bool Equals(AutoBodyType other)
        {
            return Id == other.Id && BodyName == other.BodyName;
        }
    }
}
