﻿namespace Exam.Models
{
    [System.Serializable]
    public class AutoCountryManufacturer:System.IEquatable<AutoCountryManufacturer>
    {
        public AutoCountryManufacturer() { }
        public AutoCountryManufacturer(int id, string manufacturerName) { Id = id; ManufacturerName = manufacturerName; }
        public int Id { get; set; }
        public string ManufacturerName { get; set; }

        public bool Equals(AutoCountryManufacturer other)
        {
            return Id == other.Id && ManufacturerName == other.ManufacturerName;
        }
    }
}
