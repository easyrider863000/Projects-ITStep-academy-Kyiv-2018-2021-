﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.Models
{
    [Serializable]
    public class AutoPhoto:IEquatable<AutoPhoto>
    {
        public string Path { get; set; }
        public int Id { get; set; }

        public bool Equals(AutoPhoto other)
        {
            return Id == other.Id && Path == other.Path;
        }
    }
}
