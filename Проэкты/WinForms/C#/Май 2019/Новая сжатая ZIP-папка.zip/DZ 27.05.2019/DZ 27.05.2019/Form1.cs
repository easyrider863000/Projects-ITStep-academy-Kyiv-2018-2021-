﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DZ_27._05._2019
{
    public partial class Form1 : Form
    {
        Stack<Button> btnstack = new Stack<Button>();
        Stack<ComboBox> combostack = new Stack<ComboBox>();
        Stack<TextBox> editstack = new Stack<TextBox>();
        Stack<ListBox> liststack = new Stack<ListBox>();
        Stack<TextBox> staticstack = new Stack<TextBox>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex >= 0)
            {
                Random rand = new Random();
                if(comboBox1.SelectedIndex == 0)
                {
                    Button btn = new Button();
                    btn.Location = new Point(rand.Next(this.Size.Width), rand.Next(this.Size.Height));
                    this.Controls.Add(btn);
                    btnstack.Push(btn);
                }
                else if(comboBox1.SelectedIndex == 1)
                {
                    ComboBox cmb = new ComboBox();
                    cmb.Location = new Point(rand.Next(this.Size.Width), rand.Next(this.Size.Height));
                    this.Controls.Add(cmb);
                    combostack.Push(cmb);
                }
                else if(comboBox1.SelectedIndex == 2)
                {
                    TextBox txt = new TextBox();
                    txt.Location = new Point(rand.Next(this.Size.Width), rand.Next(this.Size.Height));
                    this.Controls.Add(txt);
                    editstack.Push(txt);
                }
                else if(comboBox1.SelectedIndex == 3)
                {
                    ListBox lsb = new ListBox();
                    lsb.Location = new Point(rand.Next(this.Size.Width), rand.Next(this.Size.Height));
                    this.Controls.Add(lsb);
                    liststack.Push(lsb);
                }
                else if(comboBox1.SelectedIndex == 4)
                {
                    TextBox txt = new TextBox();
                    txt.Location = new Point(rand.Next(this.Size.Width), rand.Next(this.Size.Height));
                    this.Controls.Add(txt);
                    txt.ReadOnly = true;
                    staticstack.Push(txt);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex >= 0)
            {
                if (comboBox1.SelectedIndex == 0 && btnstack.Count > 0)
                {
                    this.Controls.Remove(btnstack.Pop());
                }
                else if (comboBox1.SelectedIndex == 1 && combostack.Count > 0)
                {
                    this.Controls.Remove(combostack.Pop());
                }
                else if (comboBox1.SelectedIndex == 2 && editstack.Count > 0)
                {
                    this.Controls.Remove(editstack.Pop());
                }
                else if (comboBox1.SelectedIndex == 3 && liststack.Count > 0)
                {
                    this.Controls.Remove(liststack.Pop());
                }
                else if (comboBox1.SelectedIndex == 4 && staticstack.Count > 0)
                {
                    this.Controls.Remove(staticstack.Pop());
                }
            }
        }
    }
}
