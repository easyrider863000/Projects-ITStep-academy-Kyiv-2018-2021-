﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization;

namespace _08._05._2019_json
{
    [Serializable]
    
    class Price:ISerializable
    {
        public double PriceOfDay { get; set; }
        public int NumberDays { get; set; }
        public double Fine1Day { get; set; }
        public int FineNumberDay { get; set; }
        public double Sum => PriceOfDay * NumberDays;
        public double Fine => Fine1Day * FineNumberDay;
        public double TotalSum => Fine + Sum;
        public static bool Serialize { get; set; }
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("PriceOfDay", PriceOfDay);
            info.AddValue("NumberDays", NumberDays);
            info.AddValue("Fine1Day", Fine1Day);
            info.AddValue("FineNumberDay", FineNumberDay);
            if (Serialize)
            {
                info.AddValue("Sum", Sum);
                info.AddValue("Fine", Fine);
                info.AddValue("TotalSum", TotalSum);
            }
        }
        private Price(SerializationInfo info, StreamingContext context)
        {
            PriceOfDay = info.GetDouble("PriceOfDay");
            NumberDays = info.GetInt32("NumberDays");
            Fine1Day = info.GetDouble("Fine1Day");
            FineNumberDay = info.GetInt32("FineNumberDay");
        }
        public Price() { }
        
        public override string ToString()
        {
            return $"Price of day: {PriceOfDay}\nNumber days: {NumberDays}\nFine one day: {Fine1Day}\nSum: {Sum}\nFine {Fine}\nTotal sum: {TotalSum}\n";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            /*Price a = new Price();//---Запись
            a.PriceOfDay = 1;
            a.NumberDays = 10;
            a.Fine1Day = 2;
            a.FineNumberDay = 3;
            Price.Serialize = false;
            SoapFormatter br = new SoapFormatter();
            try
            {
                using (FileStream fs = File.Create("price.bin"))
                {
                    br.Serialize(fs, a);
                }
            }
            catch { }*/

            /*SoapFormatter br = new SoapFormatter();//---Чтение
            try
            {
                Price obj = null;
                Price.Serialize = false;
                using (FileStream fs = File.OpenRead("price.bin"))
                {
                    obj = (Price)br.Deserialize(fs);
                }
                Console.WriteLine(obj);
            }
            catch { }*/
        }
    }
}
