﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DZ_21._05._2019
{
    public partial class Form1 : Form
    {
        DateTime dt;
        Timer t = new Timer();
        int n_but = 0;
        int num;
        public Form1()
        {
            InitializeComponent();
            
            t.Interval = 1000;
            t.Tick += (s, e) =>
            {
                label5.Text = $"{DateTime.Now.Day-dt.Day} : {DateTime.Now.Hour-dt.Hour} : {DateTime.Now.Minute-dt.Minute} : {DateTime.Now.Second-dt.Second}";
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((radioButton1.Checked || radioButton2.Checked || radioButton3.Checked) && textBox1.Text.Length >=3)
            {
                if (n_but == 0)
                {
                    dt = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
                    Random r = new Random();
                    int tmp;
                    t.Start();
                    if (radioButton1.Checked)
                    {
                        while (true)
                        {
                            tmp = r.Next(100, 1000);
                            if (tmp.ToString()[0] != tmp.ToString()[1] && tmp.ToString()[1] != tmp.ToString()[2] && tmp.ToString()[0] != tmp.ToString()[2])
                            { break; }
                        }
                        num = tmp;
                    }
                    if (radioButton2.Checked)
                    {
                        while (true)
                        {
                            tmp = r.Next(10000, 100000);
                            if (tmp.ToString()[0] != tmp.ToString()[1] && tmp.ToString()[0] != tmp.ToString()[2] && tmp.ToString()[0] != tmp.ToString()[3] && tmp.ToString()[0] != tmp.ToString()[4] && tmp.ToString()[1] != tmp.ToString()[2] && tmp.ToString()[1] != tmp.ToString()[3] && tmp.ToString()[1] != tmp.ToString()[4] && tmp.ToString()[2] != tmp.ToString()[3] && tmp.ToString()[2] != tmp.ToString()[4] && tmp.ToString()[3] != tmp.ToString()[4])
                            { break; }
                        }
                        num = tmp;
                    }
                    if (radioButton3.Checked)
                    {
                        while (true)
                        {
                            tmp = r.Next(1000000, 10000000);
                            if (tmp.ToString()[0] != tmp.ToString()[1] && tmp.ToString()[0] != tmp.ToString()[2] && tmp.ToString()[0] != tmp.ToString()[3] && tmp.ToString()[0] != tmp.ToString()[4] && tmp.ToString()[0] != tmp.ToString()[5] && tmp.ToString()[0] != tmp.ToString()[6] && tmp.ToString()[1] != tmp.ToString()[2] && tmp.ToString()[1] != tmp.ToString()[3] && tmp.ToString()[1] != tmp.ToString()[4] && tmp.ToString()[1] != tmp.ToString()[5] && tmp.ToString()[1] != tmp.ToString()[6] && tmp.ToString()[2] != tmp.ToString()[3] && tmp.ToString()[2] != tmp.ToString()[4] && tmp.ToString()[2] != tmp.ToString()[5] && tmp.ToString()[2] != tmp.ToString()[6] && tmp.ToString()[3] != tmp.ToString()[4] && tmp.ToString()[3] != tmp.ToString()[5] && tmp.ToString()[3] != tmp.ToString()[6] && tmp.ToString()[4] != tmp.ToString()[5] && tmp.ToString()[4] != tmp.ToString()[6] && tmp.ToString()[5] != tmp.ToString()[6])
                            { break; }
                        }
                        num = tmp;
                    }
                    radioButton1.Enabled = false;
                    radioButton2.Enabled = false;
                    radioButton3.Enabled = false;

                }
                //if()
                n_but++;
                label7.Text = n_but.ToString();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(e.KeyChar == 8 || Char.IsDigit(e.KeyChar)))
            {
                e.Handled = true;
            }
        }
    }
}
