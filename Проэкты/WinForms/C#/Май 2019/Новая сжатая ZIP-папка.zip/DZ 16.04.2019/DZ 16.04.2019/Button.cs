﻿namespace TestNotifyPropertyChangedCS
{
    internal class Button
    {
    }
}