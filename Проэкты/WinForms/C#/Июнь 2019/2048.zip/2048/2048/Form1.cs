﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace _2048
{
    public partial class Form1 : Form
    {
        int[,] _arr = new int[4, 4];
        int[] _checkDefeat = new int[4];
        List<Label> _cells = new List<Label>();
        int _moves = 0;
        int _score = 0;
        int _bestScore = 0;
        public Form1()
        {
            InitializeComponent();
            Text = "2048";
            Height = 460;
            Width = 340;
            LoadBestScore();
            InitializeCells();
        }
        private void SaveBestScore()
        {
            FileStream fs = new FileStream("best_score.bin", FileMode.Create);
            using (BinaryWriter bw = new BinaryWriter(fs))
            {
                bw.Write(_bestScore);
            }
        }
        private void LoadBestScore()
        {
            try
            {
                FileStream fs = new FileStream("best_score.bin", FileMode.Open);
                using (BinaryReader br = new BinaryReader(fs))
                {
                    _bestScore = br.ReadInt32();
                }
            }
            catch(Exception)
            {
                _bestScore = 0;
            }
        }
        private void InitializeCells()
        {
            int x = 15, y = 100;
            for (int i = 0; i < 4; i++)
            {
                x = 15;
                for (int j = 0; j < 4; j++)
                {
                    _cells.Add(new Label() { Text = "", Left = x, Top = y, Width = 65, Height = 65, Font = new Font("Comic Sans", 14), BorderStyle = BorderStyle.FixedSingle, BackColor = SystemColors.GrayText,TextAlign = ContentAlignment.MiddleCenter });
                    this.Controls.Add(_cells[i * 4 + j]);
                    x += 75;
                }
                y += 75;
            }
            for (int i = 0; i < _arr.GetLength(0); i++)
            {
                for (int j = 0; j < _arr.GetLength(1); j++)
                {
                    _arr[i, j] = 0;
                }
            }
            GenerateNewNumber();
            GenerateNewNumber();
            UpdateCells();
        }
        private void GenerateNewNumber()
        {
            Random rand = new Random();
            int row, col, num; bool f = true;
            while (f)
            {
                row = rand.Next(0, 4);
                col = rand.Next(0, 4);
                num = rand.Next(0, 10);
                if (_arr[row, col] == 0)
                {
                    if (num < 8)
                        _arr[row, col] = 2;
                    else
                        _arr[row, col] = 4;
                    f = false;
                }
            }
        }
        private void UpdateCells()
        {
            label2.Text = _score.ToString();
            if(_score >= _bestScore)
                _bestScore = _score;
            label3.Text = _bestScore.ToString();
            for (int i = 0; i < _arr.GetLength(0); i++)
            {
                for (int j = 0; j < _arr.GetLength(1); j++)
                {
                    if (_arr[i, j] != 0)
                    {
                        _cells[i * 4 + j].Text = _arr[i, j].ToString();
                        switch (_arr[i, j])
                        {
                            case 2:
                                _cells[i * 4 + j].BackColor = SystemColors.ControlLight;
                                break;
                            case 4:
                                _cells[i * 4 + j].BackColor = SystemColors.Info;
                                break;
                            case 8:
                                _cells[i * 4 + j].BackColor = Color.FromArgb(255, 192, 192);
                                break;
                            case 16:
                                _cells[i * 4 + j].BackColor = Color.FromArgb(255, 128, 128);
                                break;
                            case 32:
                                _cells[i * 4 + j].BackColor = Color.FromArgb(192, 80, 80);
                                break;
                            case 64:
                                _cells[i * 4 + j].BackColor = Color.Red;
                                break;
                            case 128:
                                _cells[i * 4 + j].BackColor = Color.FromArgb(255, 255, 128);
                                break;
                            case 256:
                                _cells[i * 4 + j].BackColor = Color.Yellow;
                                break;
                            case 512:
                                _cells[i * 4 + j].BackColor = Color.FromArgb(255, 232, 0);
                                break;
                            case 1024:
                                _cells[i * 4 + j].BackColor = Color.Gold;
                                break;
                            case 2048:
                                _cells[i * 4 + j].BackColor = Color.FromArgb(255, 192, 0);
                                break;
                            default:
                                _cells[i * 4 + j].BackColor = Color.Purple;
                                break;
                        }
                    }
                    else
                    {
                        _cells[i * 4 + j].Text = "";
                        _cells[i * 4 + j].BackColor = SystemColors.ControlDark;
                    }
                }
            }
        }
        private void Up()
        {
            bool f = true;
            for (int j = 0; j < _arr.GetLength(1); j++)
            {
                f = true;
                for (int i = 1; i < _arr.GetLength(0); i++)
                {
                    if(_arr[i, j] != 0)
                    {
                        for (int k = i - 1; k >= 0; k--)
                        {
                            if (_arr[k, j] == 0)
                            {
                                _arr[k, j] = _arr[k + 1, j];
                                _arr[k + 1, j] = 0;
                                _moves++;
                            }
                            else if (_arr[k, j] == _arr[k + 1, j] && f)
                            {
                                _arr[k, j] *= 2;
                                _score += _arr[k, j];
                                _arr[k + 1, j] = 0;
                                _moves++;
                                f = false;
                                break;
                            }
                        }
                    }
                }
            }
            _checkDefeat[0] = _moves;
            if (_moves == 0)
                return;
            GenerateNewNumber();
            UpdateCells();
            _moves = 0;
        }
        private void Down()
        {
            bool f = true;
            for (int i = _arr.GetLength(0) - 2; i >= 0; i--)
            {
                f = true;
                for (int j = _arr.GetLength(1) - 1; j >= 0; j--)
                {
                    if (_arr[i, j] != 0)
                    {
                        for (int k = i + 1; k < _arr.GetLength(0); k++)
                        {
                            if (_arr[k, j] == 0)
                            {
                                _arr[k, j] = _arr[k - 1, j];
                                _arr[k - 1, j] = 0;
                                _moves++;
                            }
                            else if (_arr[k, j] == _arr[k - 1, j] && f)
                            {
                                _arr[k, j] *= 2;
                                _score += _arr[k, j];
                                _arr[k - 1, j] = 0;
                                _moves++;
                                f = false;
                                break;
                            }
                        }
                    }
                }
            }
            _checkDefeat[1] = _moves;
            if (_moves == 0)
                return;
            GenerateNewNumber();
            UpdateCells();
            _moves = 0;
        }
        private void MoveRight()
        {
            bool f = true;
            for (int j = _arr.GetLength(1) - 2; j >= 0; j--)
            {
                f = true;
                for (int i = 0; i < _arr.GetLength(0); i++)
                {
                    if (_arr[i, j] != 0)
                    {
                        for (int k = j + 1; k < _arr.GetLength(1); k++)
                        {
                            if (_arr[i, k] == 0)
                            {
                                _arr[i, k] = _arr[i ,k - 1];
                                _arr[i, k - 1] = 0;
                                _moves++;
                            }
                            else if (_arr[i, k] == _arr[i, k - 1] && f)
                            {
                                _arr[i, k] *= 2;
                                _score += _arr[i, k];
                                _arr[i, k - 1] = 0;
                                _moves++;
                                f = false;
                                break;
                            }
                        }
                    }
                }
            }
            _checkDefeat[2] = _moves;
            if (_moves == 0)
                return;
            GenerateNewNumber();
            UpdateCells();
            _moves = 0;
        }
        private void MoveLeft()
        {
            bool f = true;
            for (int j = 1; j < _arr.GetLength(1); j++)
            {
                for (int i = 0; i < _arr.GetLength(0); i++)
                {
                    f = true;
                    if (_arr[i, j] != 0)
                    {
                        for (int k = j - 1; k >= 0; k--)
                        {
                            if (_arr[i, k] == 0)
                            {
                                _arr[i, k] = _arr[i, k + 1];
                                _arr[i, k + 1] = 0;
                                _moves++;
                            }
                            else if (_arr[i, k] == _arr[i, k + 1] && f)
                            {
                                _arr[i, k] *= 2;
                                _score += _arr[i, k];
                                _arr[i, k + 1] = 0;
                                _moves++;
                                f = false;
                                break;
                            }
                        }
                    }
                }
            }
            _checkDefeat[3] = _moves;
            if (_moves == 0)
                return;
            GenerateNewNumber();
            UpdateCells();
            _moves = 0;
        }
        private bool IsDefeat()
        {
            int j = 0;
            for (int i = 0; i < _checkDefeat.Length; i++)
            {
                if (_checkDefeat[i] == 0)
                    j++;
            }
            for (int i = 0; i < _cells.Count; i++)
            {
                if (_cells[i].Text != "")
                    j++;
            }
            if (j == 20)
                return true;
            return false;
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
                Up();
            else if (e.KeyCode == Keys.Down)
                Down();
            else if (e.KeyCode == Keys.Left)
                MoveLeft();
            else if (e.KeyCode == Keys.Right)
                MoveRight();
            SaveBestScore();
            if(IsDefeat())
            {
                MessageBox.Show("You lose!");
                Close();
            }
        }
    }
}