package com.itstep;

public class DZZ {
    public static void main(String[] args) {
        UsersCollection users = new UsersCollection();
        users.run();
    }
}