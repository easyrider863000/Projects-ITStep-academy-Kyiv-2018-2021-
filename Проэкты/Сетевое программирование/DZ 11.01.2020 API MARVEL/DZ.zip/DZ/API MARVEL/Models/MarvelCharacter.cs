﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_MARVEL.Models
{
    public class MarvelCharacter
    {
        public string Name { get; set; }
        public string ImageUrl { get; set; }
    }
}
