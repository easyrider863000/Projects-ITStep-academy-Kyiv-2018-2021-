1. yarn install
2. yarn watch