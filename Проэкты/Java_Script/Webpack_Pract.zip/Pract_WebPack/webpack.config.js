module.exports = {
    entry: __dirname+'/src/file1.js',
    output: {
        filename: 'bundle.js'
    },
    resolve: {
        modules: ['node_modules']
    },
    mode: 'development',
    module: {
        rules: [
            {
                test:/\.js$/,
                exclude: ["/node_modules/"],
                use: [
                    {
                        loader: "babel-loader",
                        options: {
                            presets: ["env"]
                        }
                    }
                ]
            },
            {
                test: /\.css$/i,
                use: ['style-loader', 'css-loader'],
            }
        ]
    }
};