import '../styles/style1.css'
import '../styles/style2.css'
import '../styles/style3.css'

let bgcolors = ["deepskyblue","lime","orange"]
let bdrcolors = ["dodgerblue","limegreen","orangered"]
let position = 0

let images = document.getElementsByTagName("img")
for(let img of images){
    img.style.backgroundColor=bgcolors[position]
    img.style.borderColor=bdrcolors[position]
}
document.getElementById("btn").style.backgroundColor=bgcolors[position]
document.getElementById("btn").style.borderColor=bdrcolors[position]

document.getElementById("btn").onclick = function(){
    Next()
    images = document.getElementsByTagName("img")
    for(let img of images){
        img.style.backgroundColor=bgcolors[position]
        img.style.borderColor=bdrcolors[position]
    }
    document.getElementById("btn").style.backgroundColor=bgcolors[position]
    document.getElementById("btn").style.borderColor=bdrcolors[position]
}



function Next(){
    if(position==bgcolors.length-1){
        position=0;
    }
    else{position++;}
}