import React from 'react';
import '../App.css';

class Info extends React.Component {

    render() {
        return (
            <div id="info_box">
                <h2>Погодное приложение</h2>
                <hr></hr>
                <h4>Узнайте погоду в Вашем городе</h4>
            </div>
        )
    }

}

export default Info;
