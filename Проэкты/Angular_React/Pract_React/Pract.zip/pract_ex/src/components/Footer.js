import React from 'react';
import './Footer.css';

function Footer() {
    return (
        <header className="footer">
            <div>Todo list</div>
        </header>
    );
}

export default Footer;