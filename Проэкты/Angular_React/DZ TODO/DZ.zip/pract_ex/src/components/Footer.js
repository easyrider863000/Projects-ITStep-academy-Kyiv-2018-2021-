import React from 'react';
import './Footer.css';


class Footer extends React.Component{
    constructor(props){
        super(props)
    }
    
    render(){
        return (
            <header className="footer">
            <div>Todo list</div>
        </header>
    )}
}

export default Footer;