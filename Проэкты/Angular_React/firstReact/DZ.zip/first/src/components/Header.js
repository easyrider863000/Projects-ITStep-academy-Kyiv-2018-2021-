import React from 'react';
import './Header.css';


function Header() {
    return (
        <header className="header">
            <div>My Jokes</div>
        </header>
    );
}

export default Header;