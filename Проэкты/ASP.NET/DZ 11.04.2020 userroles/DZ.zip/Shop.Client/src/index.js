
let resultElem = document.getElementById('result');


const func = () => {

    // let data = {
    //     a: 5,
    //     b: 10
    // };

    // let obj = {
    //     name: "Rostislav",
    //     lastname: "Kravets",
    //     ...data
    // };

    // console.log(obj);



    // let name = obj.name;
    // let lastname = obj.lastname;

    // let {name} = obj;


    //resultElem.innerHTML = `${name} ${lastname}`;
};

func();