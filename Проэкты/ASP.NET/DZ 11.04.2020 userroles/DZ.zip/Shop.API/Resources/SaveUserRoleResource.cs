namespace Shop.API.Resources
{
    public class SaveUserRoleResource
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }
    }
}