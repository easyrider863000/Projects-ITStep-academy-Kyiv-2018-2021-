namespace Shop.API.Resources
{
    public class RoleResource
    { 
        public int Id { get; set; }
        public string Name { get; set; }
    }
}