namespace Shop.API.Resources
{
    public class SaveRoleResource
    {
        public string Name { get; set; }
    }
}