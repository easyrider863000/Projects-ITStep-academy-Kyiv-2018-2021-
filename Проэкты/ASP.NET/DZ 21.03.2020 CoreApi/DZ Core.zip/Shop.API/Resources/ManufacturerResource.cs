namespace Shop.API.Resources
{
    public class ManufacturerResource
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}