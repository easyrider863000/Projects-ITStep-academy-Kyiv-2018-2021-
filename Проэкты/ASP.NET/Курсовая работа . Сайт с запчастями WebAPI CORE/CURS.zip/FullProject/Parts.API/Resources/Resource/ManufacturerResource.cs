namespace Parts.API.Resources
{
    public class ManufacturerResource
    {
        public int Id{get;set;}
        public string Name{get;set;}
        public string Country{get;set;}
        public string PhotoPath{get;set;}

    }
}