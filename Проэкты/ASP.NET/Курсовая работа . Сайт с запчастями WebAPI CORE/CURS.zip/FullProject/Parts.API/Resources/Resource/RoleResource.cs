namespace Parts.API.Resources.Resource
{
    public class RoleResource
    {
        public int Id{get;set;}
        public string Name{get;set;}
    }
}