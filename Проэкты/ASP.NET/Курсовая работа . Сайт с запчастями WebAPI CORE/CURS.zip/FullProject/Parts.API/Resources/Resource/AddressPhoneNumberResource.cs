namespace Parts.API.Resources.Resource
{
    public class AddressPhoneNumberResource
    {
        public int Id { get; set; }
        public int IdAddress { get; set; }
        public string PhoneNumber { get; set; }
    }
}