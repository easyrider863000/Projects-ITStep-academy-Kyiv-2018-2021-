namespace Parts.API.Resources.Resource
{
    public class AddressMailResource
    {
        public int Id { get; set; }
        public int IdAddress { get; set; }
        public string Mail { get; set; }
    }
}