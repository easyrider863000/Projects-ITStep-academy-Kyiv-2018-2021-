namespace Parts.API.Resources
{
    public class CategoryResource
    {
        public int Id{get;set;}
        public string Name{get;set;}
        public string PhotoPath{get;set;}

    }
}